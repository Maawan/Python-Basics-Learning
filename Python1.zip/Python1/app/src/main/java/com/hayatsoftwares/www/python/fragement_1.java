package com.hayatsoftwares.www.python;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class fragement_1 extends Fragment {
    private ProgressBar bar;
    View view;
    private TextView card1_title,card2_title,card3_title,card4_title,card5_title,card6_title,card1_desc,card2_desc,card3_desc,card4_desc,card5_desc,card6_desc;

    @Override
    public void onStop() {
        Toast.makeText(getActivity(), "OnStop", Toast.LENGTH_SHORT).show();
        super.onStop();
    }

    @Override
    public void onStart() {
        Toast.makeText(getActivity(), "Onstart", Toast.LENGTH_SHORT).show();
        super.onStart();
    }

    @Override
    public void onResume() {
        Toast.makeText(getContext(), "OnResume", Toast.LENGTH_SHORT).show();
        bar=(ProgressBar)view.findViewById(R.id.progress1);
        bar.setProgress(40);
        Declare();
        card1_title.setText("Introduction");
        card1_desc.setText("What is a Language, evolution of python, Role of an Operating System in running a Program, how to get started ");
        card2_title.setText("Python Fundamentals");
        card2_desc.setText("Keywords, Identifier, Literals, Creating a Variable, Variable Definition, Reading Numbers, Output using Print()");
        card3_title.setText("Data Handling");
        card3_desc.setText("Data Types, Lists, Dictionary, Arithmetic, Relational, Identity, Logical Operators, Type Casting");
        card4_title.setText("Conditional and Loops");
        card4_desc.setText("Flow Control, Decision making Statements ,range() function, for loop, while loop, Iteration Principles, Nested Loops");
        card5_title.setText("String Manipulation");
        card5_desc.setText("Intro, Transversing a String, String Operators, String Slices, String functions and Methods");

        super.onResume();
    }

    @Override
    public View onCreateView(LayoutInflater inflater,ViewGroup container,Bundle savedInstanceState) {
        Toast.makeText(getActivity(), "OnCreateView", Toast.LENGTH_SHORT).show();
        view = inflater.inflate(R.layout.fragment_python_conepts_all, container, false);
        bar=(ProgressBar)view.findViewById(R.id.progress1);
        bar.setProgress(40);





        return view;
    }
    private void Declare()
    {
        card1_title=(TextView)view.findViewById(R.id.card1_title);
        //progress1=(ProgressBar)findViewById(R.id.progress1);
        card2_title=(TextView)view.findViewById(R.id.card2_title);
        card3_title=(TextView)view.findViewById(R.id.card3_title);
        card4_title=(TextView)view.findViewById(R.id.card4_title);
        card5_title=(TextView)view.findViewById(R.id.card5_title);
        card6_title=(TextView)view.findViewById(R.id.card6_title);
        card1_desc=(TextView)view.findViewById(R.id.card1_desc);
        card2_desc=(TextView)view.findViewById(R.id.card2_desc);
        card3_desc=(TextView)view.findViewById(R.id.card3_desc);
        card4_desc=(TextView)view.findViewById(R.id.card4_desc);
        card5_desc=(TextView)view.findViewById(R.id.card5_desc);
        card6_desc=(TextView)view.findViewById(R.id.card6_desc);
    }
}
