package miwok.android.example.com.learnc;

import java.net.URL;

public class Heading {
    private String mTitle;
    private int mRn;
    public Heading(String title,int Rn){
        mTitle=title;
        mRn=Rn;
    }
    public String getmTitle(){
        return  mTitle;
    }
    public int getInt(){return mRn;}


}
