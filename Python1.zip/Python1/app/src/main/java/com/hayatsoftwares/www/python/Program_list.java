package com.hayatsoftwares.www.python;


import android.os.Bundle;


import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


public class Program_list extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_program_list);
        ArrayList<Heading> title=new ArrayList<>();
        setTitle("3");
//        URL url=http://www.cppexampler.com/what-is-c-how-can-we-define-it/;
        title.add(new Heading("What is Python",1,"https://pythom-17c93.firebaseapp.com/"));
        title.add(new Heading("What is compiler and Interpreter ?",2,"https://pythom-17c93.firebaseapp.com/"));
        // title.add(new Heading("Why '&' sign is used in Parameters of a function ?",122));
        title.add(new Heading("What Python is Used",2,"https://google.com"));
        // title.add(new Heading("Why '&' sign is used in Parameters of a function ?",122));






        RecyclerView list=(RecyclerView) findViewById(R.id.list);
        HeadingAdapter adapter=new HeadingAdapter(this,title);
        list.setAdapter(adapter);
        list.setLayoutManager(new LinearLayoutManager(this));

    }
}
