package miwok.android.example.com.learnc;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.TextView;

//import static miwok.android.example.com.learnc.R.id.myWebView;

public class Privacy extends AppCompatActivity {
    ProgressBar progressBar;
    TextView text;
    WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_privacy);
        setTitle("Privacy Policy");
        text=(TextView)findViewById(R.id.text);
        text.setVisibility(View.VISIBLE);
       progressBar=(ProgressBar)findViewById(R.id.bar);
        progressBar.setVisibility(View.VISIBLE);
         webView=(WebView) findViewById(R.id.myWebView);
        webView.loadUrl("https://hayat-softwares.000webhostapp.com/privacy_policy.html");
 //       setContentView(webView);
        webView.setWebViewClient(new WebViewClient() {

            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);
                text.setVisibility(View.INVISIBLE);
            }
        });

    }
}
