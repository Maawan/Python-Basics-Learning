package com.hayatsoftwares.www.python;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import android.os.Bundle;
//import android.support.v7.widget.CardView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.view.View;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Toast;

public class learn extends AppCompatActivity {
    WebView web;
    int temp1=0;
    int hh=0;
    String url;

    StringBuilder sb;
    int a=0;
    RelativeLayout connection;
    ProgressBar progressBar;
    String temp;
    CardView Try;
    String SHARED_PREF="shared Pref";

    @Override
    public void onBackPressed() {
//        Intent intent=new Intent(learn.this,activity_main3.class);
//        startActivity(intent);
        super.onBackPressed();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_learn);
        Intent intent = getIntent();
        if (intent != null) {
            url = intent.getStringExtra("url");

        }
        SharedPreferences sharedPreferences=getSharedPreferences(SHARED_PREF,MODE_PRIVATE);
        String[] progress=new String[50];
       load_data();
        //Toast.makeText(this, temp, Toast.LENGTH_SHORT).show();
        if(temp=="")
        {
          //  Toast.makeText(this, "First Click is Validated", Toast.LENGTH_LONG).show();
            temp1=4;
        }
        else {

            progress = temp.split(" ");
               // Toast.makeText(this, progress[6], Toast.LENGTH_SHORT).show();


            for (int j = 0; j < progress.length; j++) {

                if (progress[j].equals(url)) {
                    Toast.makeText(this, "You have Opened this File Again", Toast.LENGTH_SHORT).show();
                    temp1 = 1;
                }
                else
                {
                    hh=1;

                    save_pref();

                }

            }
        }
            if (temp1 == 0) {
            int var=0;
                for(int k=0;k<50;k++)
                {
                    if(progress[k].equals("null"))
                    {
                        var=k;
                    break;}
                }
                progress[var]=url;

            }
            else if(temp1==4)
            {
                progress[0]=url;
            }

         sb=new StringBuilder();
        for(int i=0;i<progress.length;i++)
        {
            sb.append(progress[i]).append(" ");

        }
        save_data();








        Try = (CardView) findViewById(R.id.try_again);
        //Try2=(CardView)findViewById(R.id.try_again2);
        connection = (RelativeLayout) findViewById(R.id.layout_connection);
        //error_connection=(RelativeLayout)findViewById(R.id.error_connection);
        progressBar = (ProgressBar) findViewById(R.id.progress_webview);

        web = (WebView) findViewById(R.id.web);
        web.loadUrl(url);

        if (!isNetworkAvailable()) {
            connection.setVisibility(View.VISIBLE);
        }
        Try.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isNetworkAvailable()) {
                    connection.setVisibility(View.GONE);
                    web.loadUrl(url);
                } else {
                    Toast.makeText(learn.this, "Your Network is Still not Active", Toast.LENGTH_SHORT).show();
                }
            }

        });

        web.setWebViewClient(new WebViewClient() {

            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);

            }
        });
        if(hh==1)
        {
            SharedPreferences sharedPreferences1=getSharedPreferences(SHARED_PREF,MODE_PRIVATE);
            SharedPreferences.Editor editor=sharedPreferences1.edit();
            int hello;
            hello=sharedPreferences.getInt("learn_int",0);
            hello++;
            editor.putInt("learn_int",hello);
            editor.commit();
            Toast.makeText(this, "Successfull", Toast.LENGTH_SHORT).show();
        }

    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }
    private void load_data()
    {
        SharedPreferences sharedPreferences=getSharedPreferences(SHARED_PREF,MODE_PRIVATE);
        temp=sharedPreferences.getString("PROGRESS","");
    }
    private void save_data()
    {
        SharedPreferences sharedPreferences=getSharedPreferences(SHARED_PREF,MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.putString("PROGRESS",sb.toString());
        // Toast.makeText(this, sb.toString(), Toast.LENGTH_SHORT).show();
        editor.apply();
    }
    private void save_pref()
    {
        SharedPreferences sharedPreferences=getSharedPreferences(SHARED_PREF,MODE_PRIVATE);
        SharedPreferences.Editor editor1=sharedPreferences.edit();
        editor1.putInt("Temp2120",1);
        editor1.apply();

    }
}
