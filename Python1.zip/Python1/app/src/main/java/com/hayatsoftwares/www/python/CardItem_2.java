package com.hayatsoftwares.www.python;

public class CardItem_2 {

    private int mtexttitle;
    private int mtextdesc;


    public CardItem_2(int title, int text) {
        mtexttitle = title;
        mtextdesc = text;
    }
    public int getText() {
        return mtexttitle;
    }

    public int getTitle() {
        return mtextdesc;
    }
}




